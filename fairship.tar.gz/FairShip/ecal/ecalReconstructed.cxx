#include "ecalReconstructed.h"

ClassImp(ecalReconstructed)
