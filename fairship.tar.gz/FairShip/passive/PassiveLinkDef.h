// $Id: PassiveLinkDef.h,v 1.1.1.1 2005/06/23 07:14:26 dbertini Exp $

#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class  ShipMagnet+;
#pragma link C++ class  ShipCave+;
#pragma link C++ class  ShipChamber+;
#pragma link C++ class  ShipTargetStation+;
#pragma link C++ class  MufluxTargetStation+;
#pragma link C++ class  ShipMuonShield+;
#pragma link C++ class  ShipGeoCave;
#pragma link C++ class  ShipPassiveContFact;
#pragma link C++ class  ShipTAUMagneticSpectrometer+;
#pragma link C++ class  ShipGoliath+;


#endif

