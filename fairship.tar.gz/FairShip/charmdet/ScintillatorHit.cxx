#include "ScintillatorHit.h"

ScintillatorHit::ScintillatorHit(Int_t detID, Float_t digi) : ShipHit(detID, digi) {}

ClassImp(ScintillatorHit)
