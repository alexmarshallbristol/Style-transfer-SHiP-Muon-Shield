#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class muonContFact;
#pragma link C++ class muon+;
#pragma link C++ class muonPoint+;
#pragma link C++ class muonHit+;

#endif
