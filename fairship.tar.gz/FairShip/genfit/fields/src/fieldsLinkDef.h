#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class genfit::ConstField+;
#pragma link C++ class genfit::BellField+;
#pragma link C++ class genfit::FairShipFields+;
#pragma link C++ class genfit::GoliathField+;

#endif
