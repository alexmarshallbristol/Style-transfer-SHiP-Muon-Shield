#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class hcalContFact;
#pragma link C++ class hcalPoint+;
#pragma link C++ class hcalInf+;
#pragma link C++ class hcalModule;
#pragma link C++ class hcalModuleMC;
#pragma link C++ class hcalStructure;
#pragma link C++ class hcalLightMap;
#pragma link C++ class hcal;
#pragma link C++ class hcalStructureFiller;
#pragma link C++ class hcalAnalysisSimple;

#endif
